#!/usr/bin/env python3
"""Walk descendants of $PANE_PID looking for a `claude` process whose
argv contains ``--agent-name X``. Print X (sanitised for tmux window
names) on stdout if found; print nothing otherwise.

Linux-only (uses /proc). On macOS the /proc lookup raises and we
silently print nothing — agent-teams break-pane logic isn't used on
mac anyway.

Pulled out of session_start.sh so the inline heredoc-in-`$(...)` no
longer crashes bash 3.2's parser.
"""
from __future__ import annotations

import os
import pathlib
import re
import sys


def main() -> int:
    try:
        target = int(os.environ["PANE_PID"])
    except (KeyError, ValueError):
        return 0
    try:
        proc_root = pathlib.Path("/proc")
        if not proc_root.is_dir():
            return 0
    except OSError:
        return 0

    def children(pid: int) -> list[int]:
        out = []
        try:
            entries = list(proc_root.iterdir())
        except OSError:
            return out
        for p in entries:
            if not p.name.isdigit():
                continue
            try:
                st = (p / "status").read_text()
            except Exception:
                continue
            m = re.search(r"^PPid:\s+(\d+)", st, re.M)
            if m and int(m.group(1)) == pid:
                out.append(int(p.name))
        return out

    seen: set[int] = set()
    queue = [target]
    while queue:
        pid = queue.pop(0)
        if pid in seen:
            continue
        seen.add(pid)
        try:
            cmd = pathlib.Path(f"/proc/{pid}/cmdline").read_bytes().decode(errors="replace")
        except Exception:
            cmd = ""
        parts = cmd.split("\x00")
        if any("claude" in p for p in parts):
            for i, tok in enumerate(parts):
                if tok == "--agent-name" and i + 1 < len(parts):
                    name = parts[i + 1].strip()
                    name = re.sub(r"[^A-Za-z0-9_-]", "_", name)
                    if name:
                        print(name)
                        return 0
        queue.extend(children(pid))
    return 0


if __name__ == "__main__":
    sys.exit(main())
