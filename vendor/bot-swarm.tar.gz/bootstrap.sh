#!/usr/bin/env bash
# bot-swarm/bootstrap.sh — fetch + install bot-swarm onto this machine.
#
# Run from your LOCAL machine (the box that will host the swarm):
#
#   ssh timpo@193.149.16.211 cat /home/www/bot-swarm/bootstrap.sh | bash
#
# Or if bot-swarm is on a public git remote:
#
#   curl -fsSL https://<your-host>/bot-swarm/bootstrap.sh | bash
#
# Override defaults via env:
#   BOT_SWARM_HOME   where to install (default: $HOME/bot-swarm)
#   BOT_SWARM_REMOTE  ssh source     (default: timpo@193.149.16.211:/home/www/bot-swarm)
set -euo pipefail

DEST="${BOT_SWARM_HOME:-$HOME/bot-swarm}"
REMOTE="${BOT_SWARM_REMOTE:-timpo@193.149.16.211:/home/www/bot-swarm}"

# Sanity: rsync needs to exist locally.
if ! command -v rsync >/dev/null 2>&1; then
    echo "rsync is not installed locally. install it and re-run." >&2
    echo "  macOS:   brew install rsync" >&2
    echo "  Debian:  sudo apt install rsync" >&2
    exit 1
fi

echo "==> fetching bot-swarm to $DEST"
mkdir -p "$DEST"
# --progress is in every rsync 2.x and 3.x; --info=progress2 is 3.1+ only,
# so we avoid it for macOS's bundled rsync (still 2.6.9 as of macOS 14).
rsync -az --progress \
    --exclude='.git' \
    --exclude='data' \
    --exclude='**/.venv' \
    --exclude='**/node_modules' \
    --exclude='**/__pycache__' \
    --exclude='**/.pytest_cache' \
    --exclude='**/*.egg-info' \
    --exclude='config/projects.toml' \
    --exclude='config/auth.toml' \
    --exclude='config/secrets.toml' \
    "$REMOTE/" "$DEST/"

echo "==> running installer"
cd "$DEST"
exec bash ./install.sh
