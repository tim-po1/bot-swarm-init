"""Tests for the auto-sleep scheduled tick."""
from __future__ import annotations

import json
import types
from pathlib import Path

import pytest

from bot_squad_worker import swarm_autosleep as A
from bot_squad_worker import swarm_strategy as ST


def _cfg(tmp_path: Path) -> types.SimpleNamespace:
    return types.SimpleNamespace(
        data_dir=tmp_path / "data",
        projects={"stash": object()},
    )


def _write_jsonl(path: Path, n_lines: int = 10) -> int:
    """Make a jsonl big enough to be over threshold for tests. Returns
    final byte size."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        for i in range(n_lines):
            f.write(json.dumps(
                {"type": "user", "message": {"role": "user", "content": "x" * 500}}
            ) + "\n")
    return path.stat().st_size


def _stub_list_sessions(rows, monkeypatch):
    import bot_squad_worker.swarm_autosleep as M
    monkeypatch.setattr(M._sessions, "list_sessions", lambda cfg, slug: rows)


def _stub_user_home(tmp_path, monkeypatch):
    import bot_squad_worker.swarm_autosleep as M
    monkeypatch.setattr(M._sleep, "_user_home", lambda: tmp_path / "home")


def _stub_sleep_calls(monkeypatch):
    import bot_squad_worker.swarm_autosleep as M
    calls: list[dict] = []

    def fake_sleep_expert(cfg, slug, sid):
        calls.append({"op": "sleep", "slug": slug, "sid": sid})
        return {"ok": True, "role": "x", "compacted_bytes": 9999,
                "mark_before": 0, "mark_after": 9999, "scribe_stdout_tail": ""}

    def fake_respawn_expert(cfg, slug, sid):
        calls.append({"op": "respawn", "slug": slug, "sid": sid})
        return {"ok": True, "old_sid": sid, "new_sid": sid + "-new",
                "role": "x", "window": "w", "drained_lines": 0}

    monkeypatch.setattr(M._sleep, "sleep_expert", fake_sleep_expert)
    monkeypatch.setattr(M._sessions, "respawn_expert", fake_respawn_expert)
    return calls


# ---------------------------------------------------------------------------
# Gating: disabled / no sessions / no role
# ---------------------------------------------------------------------------

def test_tick_noop_when_strategy_disabled(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    # No strategy.toml — defaults have auto_sleep_enabled = False.
    _stub_list_sessions([{
        "sid": "S-u-be-p0", "role": "backend-expert", "status": "active",
        "cwd": "/c", "claude_uuid": "u",
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)
    out = A.autosleep_tick(cfg)
    assert out["fired"] == []
    assert calls == []


def test_tick_skips_session_without_role(tmp_path, monkeypatch):
    """bot-squad legacy sessions (no role) must not be slept."""
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {"auto_sleep_enabled": True})
    _stub_list_sessions([{
        "sid": "S-u-leg-p0", "role": None, "status": "active",
        "cwd": "/c", "claude_uuid": "u",
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)
    out = A.autosleep_tick(cfg)
    assert out["fired"] == []
    assert calls == []


def test_tick_skips_suspended_sessions(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {"auto_sleep_enabled": True})
    _stub_list_sessions([{
        "sid": "S-u-be-p0", "role": "backend-expert", "status": "suspended",
        "cwd": "/c", "claude_uuid": "u",
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)
    A.autosleep_tick(cfg)
    assert calls == []


def test_tick_skips_coordinator_by_default(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {
        "auto_sleep_enabled": True,
        "auto_sleep_threshold_bytes": 100,
    })
    cwd = "/home/u/proj"
    uuid = "uuid-coord"
    jsonl = tmp_path / "home" / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl)
    _stub_user_home(tmp_path, monkeypatch)
    _stub_list_sessions([{
        "sid": "S-u-coord-p0", "role": "coordinator", "status": "active",
        "cwd": cwd, "claude_uuid": uuid,
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)
    A.autosleep_tick(cfg)
    assert calls == []  # default includes_coordinator=False blocks it


# ---------------------------------------------------------------------------
# Firing path
# ---------------------------------------------------------------------------

def test_tick_fires_sleep_and_respawn_over_threshold(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {
        "auto_sleep_enabled": True,
        "auto_sleep_threshold_bytes": 100,  # tiny so our fixture clears it
        "auto_sleep_min_interval_sec": 0,
    })
    cwd = "/home/u/proj"
    uuid = "uuid-be"
    jsonl = tmp_path / "home" / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    size = _write_jsonl(jsonl)
    assert size > 100
    _stub_user_home(tmp_path, monkeypatch)
    _stub_list_sessions([{
        "sid": "S-u-be-p0", "role": "backend-expert", "status": "active",
        "cwd": cwd, "claude_uuid": uuid,
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)

    out = A.autosleep_tick(cfg)
    ops = [c["op"] for c in calls]
    assert ops == ["sleep", "respawn"]
    assert len(out["fired"]) == 1
    assert out["fired"][0]["role"] == "backend-expert"
    assert out["fired"][0]["respawned"] is True


def test_tick_sleep_only_when_respawn_disabled(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {
        "auto_sleep_enabled": True,
        "auto_sleep_threshold_bytes": 100,
        "auto_sleep_respawn": False,
        "auto_sleep_min_interval_sec": 0,
    })
    cwd = "/home/u/proj"
    uuid = "uuid-be"
    jsonl = tmp_path / "home" / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl)
    _stub_user_home(tmp_path, monkeypatch)
    _stub_list_sessions([{
        "sid": "S-u-be-p0", "role": "backend-expert", "status": "active",
        "cwd": cwd, "claude_uuid": uuid,
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)

    A.autosleep_tick(cfg)
    assert [c["op"] for c in calls] == ["sleep"]  # no respawn


def test_tick_under_threshold_does_not_fire(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {
        "auto_sleep_enabled": True,
        "auto_sleep_threshold_bytes": 1_000_000,  # way more than fixture
        "auto_sleep_min_interval_sec": 0,
    })
    cwd = "/home/u/proj"
    uuid = "uuid-be"
    jsonl = tmp_path / "home" / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl)
    _stub_user_home(tmp_path, monkeypatch)
    _stub_list_sessions([{
        "sid": "S-u-be-p0", "role": "backend-expert", "status": "active",
        "cwd": cwd, "claude_uuid": uuid,
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)
    A.autosleep_tick(cfg)
    assert calls == []


def test_tick_respects_min_interval(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {
        "auto_sleep_enabled": True,
        "auto_sleep_threshold_bytes": 100,
        "auto_sleep_min_interval_sec": 600,
    })
    cwd = "/home/u/proj"
    uuid = "uuid-be"
    jsonl = tmp_path / "home" / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl)
    _stub_user_home(tmp_path, monkeypatch)
    # Pre-write a fresh sleep_mark (mtime = now) so we're within the
    # min_interval window.
    mark = tmp_path / "data" / "stash" / "experts" / "backend-expert" / "sleep_mark"
    mark.parent.mkdir(parents=True, exist_ok=True)
    mark.write_text("0")
    _stub_list_sessions([{
        "sid": "S-u-be-p0", "role": "backend-expert", "status": "active",
        "cwd": cwd, "claude_uuid": uuid,
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)
    out = A.autosleep_tick(cfg)
    assert calls == []
    # The skipped event records the reason for operator visibility.
    assert out["skipped"]
    assert out["skipped"][0]["reason"] == "min_interval"


def test_tick_fires_coordinator_when_strategy_opts_in(tmp_path, monkeypatch):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {
        "auto_sleep_enabled": True,
        "auto_sleep_threshold_bytes": 100,
        "auto_sleep_min_interval_sec": 0,
        "auto_sleep_includes_coordinator": True,
    })
    cwd = "/home/u/proj"
    uuid = "uuid-coord"
    jsonl = tmp_path / "home" / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl)
    _stub_user_home(tmp_path, monkeypatch)
    _stub_list_sessions([{
        "sid": "S-u-coord-p0", "role": "coordinator", "status": "active",
        "cwd": cwd, "claude_uuid": uuid,
    }], monkeypatch)
    calls = _stub_sleep_calls(monkeypatch)
    A.autosleep_tick(cfg)
    assert any(c["op"] == "sleep" for c in calls)


def test_tick_continues_when_one_project_errors(tmp_path, monkeypatch):
    """A bad strategy for one project must not block other projects."""
    cfg = types.SimpleNamespace(
        data_dir=tmp_path / "data",
        projects={"good": object(), "broken": object()},
    )
    # Bad TOML in the broken project so strategy read fails.
    (tmp_path / "data" / "broken").mkdir(parents=True)
    (tmp_path / "data" / "broken" / "strategy.toml").write_text("garbage = = =")

    # Good project: enabled, with an over-threshold session.
    ST.write_strategy(cfg, "good", {
        "auto_sleep_enabled": True,
        "auto_sleep_threshold_bytes": 100,
        "auto_sleep_min_interval_sec": 0,
    })
    cwd = "/home/u/proj"
    uuid = "uuid-good"
    jsonl = tmp_path / "home" / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl)
    _stub_user_home(tmp_path, monkeypatch)

    def fake_list_sessions(cfg, slug):
        if slug == "good":
            return [{
                "sid": "S-u-x-p0", "role": "backend-expert", "status": "active",
                "cwd": cwd, "claude_uuid": uuid,
            }]
        return []

    import bot_squad_worker.swarm_autosleep as M
    monkeypatch.setattr(M._sessions, "list_sessions", fake_list_sessions)
    calls = _stub_sleep_calls(monkeypatch)

    out = A.autosleep_tick(cfg)
    assert any(s["slug"] == "broken" for s in out["skipped"])  # error recorded
    assert any(f["slug"] == "good" for f in out["fired"])       # good still fired
