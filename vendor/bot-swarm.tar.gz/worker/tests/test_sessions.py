"""Tests for worker.sessions — session list/pause/resume/spawn."""
from __future__ import annotations

import subprocess
import time
from pathlib import Path
from typing import Any

import pytest

from bot_squad_worker.sessions import (
    PaneInfo,
    compute_sid,
    discover_claude_uuid,
    list_panes,
    list_sessions,
    pause,
    resume,
    spawn,
    _read_session_metadata,
    _write_session_metadata,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_cfg(tmp_path: Path, repo_path: Path | None = None) -> Any:
    """Build a minimal Config-like object for testing."""
    from bot_squad_worker.config import Config
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir(exist_ok=True)
    data_dir = tmp_path / "data"
    (data_dir / "test-project" / "backlog").mkdir(parents=True, exist_ok=True)
    (data_dir / "test-project" / "sessions").mkdir(parents=True, exist_ok=True)

    rp = str(repo_path or (tmp_path / "repo"))
    (cfg_dir / "projects.toml").write_text(
        f'[projects.test-project]\n'
        f'slug = "test-project"\n'
        f'display_name = "Test Project"\n'
        f'repo_path = "{rp}"\n'
        f'deploy_branch = "bot_squad/dev"\n'
        f'master_branch = "master"\n'
        f'prod_url = ""\n'
        f'staging_url = ""\n'
        f'dev_url = ""\n'
        f'deploy_targets = ["staging"]\n'
        f'tg_chat = "0"\n'
        f'created_at = 2026-05-10\n'
    )
    (cfg_dir / "secrets.toml").write_text('[telegram]\nbot_token = ""\n')
    cfg = Config.load(cfg_dir)

    # Build a simple namespace object with the right data_dir
    import types
    patched = types.SimpleNamespace(
        projects=cfg.projects,
        data_dir=data_dir,
        tg_bot_token=cfg.tg_bot_token,
    )
    return patched


def _fake_pane(pane_id="%2", window="mywin", pid="1234", cwd="/tmp/repo", command="claude"):
    return PaneInfo(pane_id=pane_id, window=window, pid=pid, cwd=cwd, command=command)


# ---------------------------------------------------------------------------
# Unit tests: helpers
# ---------------------------------------------------------------------------

def test_compute_sid_strips_pct():
    assert compute_sid("alice", "mywin", "%2") == "S-alice-mywin-p2"


def test_compute_sid_no_pct():
    assert compute_sid("alice", "mywin", "3") == "S-alice-mywin-p3"


def test_discover_claude_uuid_returns_stem(tmp_path):
    proj_dir = tmp_path / ".claude" / "projects" / "home-alice-myrepo"
    proj_dir.mkdir(parents=True)
    uuid_file = proj_dir / "abc123-0000-0000-0000-000000000000.jsonl"
    uuid_file.write_text("{}")
    result = discover_claude_uuid("/home/alice/myrepo", str(tmp_path))
    assert result == "abc123-0000-0000-0000-000000000000"


def test_discover_claude_uuid_no_dir(tmp_path):
    result = discover_claude_uuid("/nonexistent/path", str(tmp_path))
    assert result is None


def test_discover_claude_uuid_no_jsonl(tmp_path):
    proj_dir = tmp_path / ".claude" / "projects" / "home-alice-myrepo"
    proj_dir.mkdir(parents=True)
    result = discover_claude_uuid("/home/alice/myrepo", str(tmp_path))
    assert result is None


def test_discover_claude_uuid_returns_latest(tmp_path):
    proj_dir = tmp_path / ".claude" / "projects" / "tmp-repo"
    proj_dir.mkdir(parents=True)
    old = proj_dir / "old-uuid.jsonl"
    new = proj_dir / "new-uuid.jsonl"
    old.write_text("{}")
    time.sleep(0.01)
    new.write_text("{}")
    result = discover_claude_uuid("/tmp/repo", str(tmp_path))
    assert result == "new-uuid"


def test_read_write_session_metadata_roundtrip(tmp_path):
    path = tmp_path / "S-test.md"
    meta = {"sid": "S-x", "status": "paused", "linked_tasks": ["T-0001"], "cwd": "/tmp"}
    _write_session_metadata(path, meta)
    result = _read_session_metadata(path)
    assert result["sid"] == "S-x"
    assert result["status"] == "paused"
    assert result["linked_tasks"] == ["T-0001"]


def test_read_session_metadata_missing_file(tmp_path):
    result = _read_session_metadata(tmp_path / "nonexistent.md")
    assert result is None


def test_read_session_metadata_empty_list(tmp_path):
    path = tmp_path / "S-test.md"
    _write_session_metadata(path, {"linked_tasks": []})
    result = _read_session_metadata(path)
    assert result["linked_tasks"] == []


# ---------------------------------------------------------------------------
# list_panes — monkeypatched subprocess
# ---------------------------------------------------------------------------

def test_list_panes_parses_output(monkeypatch):
    fake_output = "%2|mywin|1234|/tmp/repo|claude\n%3|otherwin|5678|/tmp/other|bash\n"

    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(args, returncode=0, stdout=fake_output, stderr="")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)

    panes = list_panes()
    assert len(panes) == 2
    assert panes[0].pane_id == "%2"
    assert panes[0].window == "mywin"
    assert panes[0].command == "claude"
    assert panes[1].command == "bash"


def test_list_panes_returns_empty_on_error(monkeypatch):
    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(args, returncode=1, stdout="", stderr="no server")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)

    panes = list_panes()
    assert panes == []


# ---------------------------------------------------------------------------
# list_sessions
# ---------------------------------------------------------------------------

def test_list_sessions_active_pane(tmp_path, monkeypatch):
    """Active claude pane in the project's repo shows up."""
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    fake_pane_output = f"%2|mywin|1234|{repo}|claude\n"

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, fake_pane_output, "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    rows = list_sessions(cfg, "test-project")
    assert len(rows) == 1
    assert rows[0]["status"] == "active"
    assert rows[0]["sid"] == "S-testuser-mywin-p2"
    assert rows[0]["window"] == "mywin"
    # Phase 6: initiative key is always present (empty string when unset).
    assert "initiative" in rows[0]
    assert rows[0]["initiative"] == ""


def test_list_sessions_filters_non_claude_panes(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    fake_pane_output = f"%2|mywin|1234|{repo}|bash\n%3|win2|5678|{repo}|python\n"

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, fake_pane_output, "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    rows = list_sessions(cfg, "test-project")
    assert rows == []


def test_list_sessions_filters_wrong_repo(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    fake_pane_output = "/tmp/other-repo|bash|1234|%2|win\n%2|win|1234|/tmp/other|claude\n"

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, fake_pane_output, "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    rows = list_sessions(cfg, "test-project")
    assert rows == []


def test_list_sessions_includes_paused(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    # Write a paused session metadata file
    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    meta_path = sessions_dir / "S-testuser-mywin-p5.md"
    _write_session_metadata(meta_path, {
        "sid": "S-testuser-mywin-p5",
        "status": "paused",
        "window": "mywin",
        "cwd": str(repo),
        "claude_uuid": "some-uuid",
        "paused_at": "2026-05-10T12:00:00Z",
        "linked_tasks": [],
    })

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    rows = list_sessions(cfg, "test-project")
    assert len(rows) == 1
    # Paused md with no live pane is surfaced as "suspended" (resurrectable).
    assert rows[0]["status"] == "suspended"
    assert rows[0]["sid"] == "S-testuser-mywin-p5"
    # Phase 6: initiative key is always present (empty string when md omits it).
    assert "initiative" in rows[0]
    assert rows[0]["initiative"] == ""


def test_list_sessions_active_pane_with_initiative(tmp_path, monkeypatch):
    """Active pane with an initiative recorded in its md surfaces it."""
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    # Pre-write a session md with an initiative field (mimics the hook).
    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    meta_path = sessions_dir / "S-testuser-mywin-p2.md"
    _write_session_metadata(meta_path, {
        "sid": "S-testuser-mywin-p2",
        "status": "active",
        "window": "mywin",
        "cwd": str(repo),
        "claude_uuid": "some-uuid",
        "task_id": "~",
        "initiative": "v0.7-news-subscriptions.md",
        "started_at": "2026-05-12T10:00:00Z",
    })

    fake_pane_output = f"%2|mywin|1234|{repo}|claude\n"

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, fake_pane_output, "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    rows = list_sessions(cfg, "test-project")
    assert len(rows) == 1
    assert rows[0]["initiative"] == "v0.7-news-subscriptions.md"


def test_list_sessions_suspended_with_initiative(tmp_path, monkeypatch):
    """Suspended-md path surfaces initiative from frontmatter."""
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    meta_path = sessions_dir / "S-testuser-mywin-p7.md"
    _write_session_metadata(meta_path, {
        "sid": "S-testuser-mywin-p7",
        "status": "suspended",
        "window": "mywin",
        "cwd": str(repo),
        "claude_uuid": "another-uuid",
        "initiative": "foo.md",
        "linked_tasks": [],
    })

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    rows = list_sessions(cfg, "test-project")
    assert len(rows) == 1
    assert rows[0]["initiative"] == "foo.md"


def test_list_sessions_unknown_slug(tmp_path, monkeypatch):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)

    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)

    with pytest.raises(ActionError, match="unknown project slug"):
        list_sessions(cfg, "no-such-slug")


# ---------------------------------------------------------------------------
# pause (Ctrl-C only; pane stays open)
# ---------------------------------------------------------------------------

def test_pause_sends_ctrl_c_and_marks_paused(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    calls = []

    def fake_run(args, **kwargs):
        calls.append(args)
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, f"%2|mywin|1234|{repo}|claude\n", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    result = pause(cfg, "test-project", "S-testuser-mywin-p2")

    assert result == {"ok": True, "paused": True}

    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    meta_file = sessions_dir / "S-testuser-mywin-p2.md"
    assert meta_file.exists()
    meta = _read_session_metadata(meta_file)
    assert meta["status"] == "paused"

    # Only Ctrl-C — no /exit, no kill-pane.
    send_key_calls = [c for c in calls if "send-keys" in c]
    assert len(send_key_calls) == 1
    assert "C-c" in send_key_calls[0]
    assert not any("kill-pane" in c for c in calls)


def test_pause_unknown_sid_raises(tmp_path, monkeypatch):
    from bot_squad_worker.actions import ActionError
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    with pytest.raises(ActionError, match="no active pane"):
        pause(cfg, "test-project", "S-testuser-nowin-p99")


# ---------------------------------------------------------------------------
# suspend (close pane, preserve registry for resurrect)
# ---------------------------------------------------------------------------

def test_suspend_closes_pane_and_marks_suspended(tmp_path, monkeypatch):
    from bot_squad_worker.sessions import suspend

    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    calls: list[list[str]] = []

    def fake_run(args, **kwargs):
        calls.append(args)
        if "list-panes" in args:
            list_panes_calls = sum(1 for c in calls if "list-panes" in c)
            if list_panes_calls <= 1:
                return subprocess.CompletedProcess(args, 0, f"%2|mywin|1234|{repo}|claude\n", "")
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    result = suspend(cfg, "test-project", "S-testuser-mywin-p2")

    assert result == {"ok": True, "suspended": True}

    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    meta_file = sessions_dir / "S-testuser-mywin-p2.md"
    assert meta_file.exists()
    meta = _read_session_metadata(meta_file)
    assert meta["status"] == "suspended"

    send_key_calls = [c for c in calls if "send-keys" in c]
    assert any("C-c" in c for c in send_key_calls)
    assert any("/exit" in c for c in send_key_calls)


def test_suspend_no_live_pane_just_normalises_md(tmp_path, monkeypatch):
    """Suspending a zombie (no live pane) preserves md and marks suspended."""
    from bot_squad_worker.sessions import suspend

    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    meta_path = sessions_dir / "S-testuser-zombie-p7.md"
    _write_session_metadata(meta_path, {
        "sid": "S-testuser-zombie-p7",
        "status": "active",
        "window": "zombie",
        "cwd": str(repo),
        "claude_uuid": "zombie-uuid",
        "task_id": "~",
        "started_at": "2026-05-10T12:00:00Z",
        "linked_tasks": [],
    })

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    result = suspend(cfg, "test-project", "S-testuser-zombie-p7")
    assert result["ok"] is True
    assert result["suspended"] is True
    assert result["already_gone"] is True

    meta = _read_session_metadata(meta_path)
    assert meta["status"] == "suspended"
    assert meta["claude_uuid"] == "zombie-uuid"


# ---------------------------------------------------------------------------
# spawn
# ---------------------------------------------------------------------------

def test_spawn_creates_new_window(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    pane_calls = []

    def fake_run(args, **kwargs):
        pane_calls.append(args)
        if "list-panes" in args:
            # Before spawn: empty; after spawn: has the new pane
            if len([c for c in pane_calls if "list-panes" in c]) > 1:
                return subprocess.CompletedProcess(args, 0, f"%7|spec5-smoke|2222|{repo}|claude\n", "")
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    result = spawn(cfg, "test-project", "spec5-smoke")
    assert result["ok"] is True
    assert result["sid"] == "S-testuser-spec5-smoke-p7"


def test_spawn_with_task_and_initiative_stamps_task_md(tmp_path, monkeypatch):
    """T-0038: spawn(task_id=..., initiative=...) writes the initiative
    into the task md frontmatter when absent."""
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    backlog = cfg.data_dir / "test-project" / "backlog"
    task_md = backlog / "T-0007-foo.md"
    task_md.write_text(
        "---\nid: T-0007\ntitle: Foo\nstatus: open\n---\n\nbody\n"
    )

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, f"%2|w|11|{repo}|claude\n", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "u")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    spawn(cfg, "test-project", "w",
          task_id="T-0007", initiative="multi-server-installation-process.md")

    txt = task_md.read_text()
    assert "initiative: multi-server-installation-process.md" in txt


def test_spawn_does_not_clobber_existing_initiative(tmp_path, monkeypatch):
    """T-0038: existing-wins. If the task already has an initiative, don't
    overwrite it on spawn."""
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    backlog = cfg.data_dir / "test-project" / "backlog"
    task_md = backlog / "T-0008-foo.md"
    task_md.write_text(
        "---\nid: T-0008\ntitle: Foo\nstatus: open\n"
        "initiative: original.md\n---\n\nbody\n"
    )

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, f"%3|w|11|{repo}|claude\n", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "u")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    spawn(cfg, "test-project", "w",
          task_id="T-0008", initiative="different.md")

    txt = task_md.read_text()
    assert "initiative: original.md" in txt
    assert "initiative: different.md" not in txt


def test_spawn_sends_initial_prompt(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    key_calls = []
    new_window_called = [False]

    def fake_run(args, **kwargs):
        if "send-keys" in args:
            key_calls.append(args)
            return subprocess.CompletedProcess(args, 0, "", "")
        if "new-window" in args:
            new_window_called[0] = True
            return subprocess.CompletedProcess(args, 0, "", "")
        if "list-panes" in args:
            # Before new-window: no panes. After: one new pane.
            if new_window_called[0]:
                return subprocess.CompletedProcess(args, 0, f"%8|newwin|3333|{repo}|claude\n", "")
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    spawn(cfg, "test-project", "newwin", initial_prompt="hello world")

    assert any("hello world" in str(c) for c in key_calls), \
        f"expected hello world send-keys; got: {key_calls}"


# ---------------------------------------------------------------------------
# resume
# ---------------------------------------------------------------------------

def test_resume_resumes_paused_session(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    _write_session_metadata(sessions_dir / "S-testuser-mywin-p5.md", {
        "sid": "S-testuser-mywin-p5",
        "status": "paused",
        "window": "mywin",
        "cwd": str(repo),
        "claude_uuid": "fake-uuid-1234",
        "paused_at": "2026-05-10T12:00:00Z",
        "linked_tasks": [],
    })

    pane_list_calls = []

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            pane_list_calls.append(1)
            # First call (pre-spawn check): empty; subsequent: new pane
            if len(pane_list_calls) <= 1:
                return subprocess.CompletedProcess(args, 0, "", "")
            return subprocess.CompletedProcess(args, 0, f"%9|mywin|9999|{repo}|claude\n", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "testuser")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    result = resume(cfg, "test-project", "S-testuser-mywin-p5")
    assert result["ok"] is True
    new_sid = result["sid"]
    assert new_sid.startswith("S-testuser-")

    # New metadata file should exist and be active
    new_meta_file = sessions_dir / f"{new_sid}.md"
    assert new_meta_file.exists()
    meta = _read_session_metadata(new_meta_file)
    assert meta["status"] == "active"


def test_resume_unknown_sid_raises(tmp_path, monkeypatch):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)

    with pytest.raises(ActionError, match="no metadata found"):
        resume(cfg, "test-project", "S-testuser-nowin-p0")


# ---------------------------------------------------------------------------
# T-0080: owner field plumbing
# ---------------------------------------------------------------------------

def test_spawn_passes_owner_env_to_shell(tmp_path, monkeypatch):
    """spawn(owner=X) bakes BOT_SQUAD_OWNER=X into the bash -lc shell cmd
    so the SessionStart hook can stamp owner into the SessionMd."""
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    captured_shell_cmd: list[str] = []

    def fake_run(args, **kwargs):
        if "new-window" in args:
            # bash -lc <cmd> — capture the cmd string.
            try:
                i = args.index("-lc")
                captured_shell_cmd.append(args[i + 1])
            except (ValueError, IndexError):
                pass
            return subprocess.CompletedProcess(args, 0, "", "")
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, f"%4|w|123|{repo}|claude\n", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "u")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    spawn(cfg, "test-project", "w", owner="aqice")

    assert captured_shell_cmd, "expected at least one new-window call"
    assert "BOT_SQUAD_OWNER=aqice" in captured_shell_cmd[0]


def test_spawn_rejects_invalid_owner(tmp_path, monkeypatch):
    """Owner must be alnum/_./-; reject shell-meaningful chars."""
    from bot_squad_worker.actions import ActionError
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    import bot_squad_worker.sessions as S
    # Stub out tmux: ensure-session probe + list-panes. Validation fires
    # before tmux new-window, so we only need _run to return ok for the
    # ensure-session path.
    monkeypatch.setattr(S, "_run",
        lambda args, **kw: subprocess.CompletedProcess(args, 0, "", ""))
    monkeypatch.setattr(S, "_get_current_user", lambda: "u")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    with pytest.raises(ActionError, match="invalid owner"):
        spawn(cfg, "test-project", "w", owner="bob; rm -rf /")


def test_spawn_without_owner_omits_env_var(tmp_path, monkeypatch):
    """Legacy callers (no owner kwarg) must not get an empty BOT_SQUAD_OWNER=."""
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    captured: list[str] = []

    def fake_run(args, **kwargs):
        if "new-window" in args:
            try:
                i = args.index("-lc")
                captured.append(args[i + 1])
            except (ValueError, IndexError):
                pass
            return subprocess.CompletedProcess(args, 0, "", "")
        if "list-panes" in args:
            return subprocess.CompletedProcess(args, 0, f"%5|w|123|{repo}|claude\n", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "u")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    spawn(cfg, "test-project", "w")
    assert captured
    assert "BOT_SQUAD_OWNER" not in captured[0]


def test_list_sessions_emits_owner_from_md(tmp_path, monkeypatch):
    """list_sessions surfaces SessionMd `owner:` for both active + suspended."""
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    # Suspended (md-only) row with owner stamped.
    _write_session_metadata(sessions_dir / "S-u-sus-p1.md", {
        "sid": "S-u-sus-p1",
        "status": "suspended",
        "window": "sus",
        "cwd": str(repo),
        "claude_uuid": "abc",
        "task_id": "~",
        "started_at": "2026-05-16T10:00:00Z",
        "suspended_at": "2026-05-16T11:00:00Z",
        "owner": "aqice",
    })
    # Active row — its md exists too, owner stamped.
    _write_session_metadata(sessions_dir / "S-u-act-p2.md", {
        "sid": "S-u-act-p2",
        "status": "active",
        "window": "act",
        "cwd": str(repo),
        "claude_uuid": "def",
        "task_id": "~",
        "started_at": "2026-05-16T10:30:00Z",
        "owner": "alexey",
    })

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            # Only the "active" row has a live pane.
            return subprocess.CompletedProcess(
                args, 0, f"%2|act|111|{repo}|claude\n", "",
            )
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "u")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    rows = list_sessions(cfg, "test-project")
    by_sid = {r["sid"]: r for r in rows}
    assert by_sid["S-u-act-p2"]["owner"] == "alexey"
    assert by_sid["S-u-sus-p1"]["owner"] == "aqice"


def test_suspend_preserves_owner_field(tmp_path, monkeypatch):
    """suspend() rewrites the md but must keep owner stamped."""
    from bot_squad_worker.sessions import suspend
    repo = tmp_path / "repo"
    repo.mkdir()
    cfg = _make_cfg(tmp_path, repo)

    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    _write_session_metadata(sessions_dir / "S-u-w-p3.md", {
        "sid": "S-u-w-p3",
        "status": "active",
        "window": "w",
        "cwd": str(repo),
        "claude_uuid": "uuid-1",
        "task_id": "~",
        "started_at": "2026-05-16T10:00:00Z",
        "owner": "aqice",
    })

    pane_calls = [0]

    def fake_run(args, **kwargs):
        if "list-panes" in args:
            pane_calls[0] += 1
            # First call: pane live. After kill: gone.
            if pane_calls[0] == 1:
                return subprocess.CompletedProcess(args, 0, f"%3|w|11|{repo}|claude\n", "")
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "u")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    suspend(cfg, "test-project", "S-u-w-p3")
    meta = _read_session_metadata(sessions_dir / "S-u-w-p3.md")
    assert meta["owner"] == "aqice"


# ---------------------------------------------------------------------------
# Bot-swarm: expert directory layout seeding + role surfacing
# ---------------------------------------------------------------------------

def test_seed_expert_layout_creates_files(tmp_path):
    from bot_squad_worker.sessions import _seed_expert_layout
    import types
    cfg = types.SimpleNamespace(data_dir=tmp_path / "data")
    _seed_expert_layout(cfg, "stash", "backend-expert")
    base = tmp_path / "data" / "stash" / "experts" / "backend-expert"
    assert (base / "identity.md").is_file()
    assert (base / "memory" / "MEMORY.md").is_file()
    assert "backend-expert" in (base / "identity.md").read_text()


def test_seed_expert_layout_idempotent(tmp_path):
    from bot_squad_worker.sessions import _seed_expert_layout
    import types
    cfg = types.SimpleNamespace(data_dir=tmp_path / "data")
    _seed_expert_layout(cfg, "stash", "planner")
    identity = tmp_path / "data" / "stash" / "experts" / "planner" / "identity.md"
    identity.write_text("custom content")
    _seed_expert_layout(cfg, "stash", "planner")  # must not clobber
    assert identity.read_text() == "custom content"


def test_seed_expert_layout_uses_template_when_available(tmp_path):
    """When templates/identity/<role>.md exists, the seeded identity.md
    should be the template content, not the generic stub.
    """
    from bot_squad_worker.sessions import _seed_expert_layout
    import types
    cfg = types.SimpleNamespace(data_dir=tmp_path / "data")
    _seed_expert_layout(cfg, "stash", "coordinator")
    identity = tmp_path / "data" / "stash" / "experts" / "coordinator" / "identity.md"
    text = identity.read_text()
    # Coordinator template is curated and substantially longer than the stub.
    assert "primary surface the user talks to" in text
    # Stub marker text shouldn't appear as the document's own content
    # (the template legitimately mentions the stub string while
    # describing the first-wake fallback).
    assert "TODO: describe this expert's responsibility sphere" not in text


# ---------------------------------------------------------------------------
# Bot-swarm: respawn_expert
# ---------------------------------------------------------------------------

def _setup_respawn_fixture(tmp_path, monkeypatch, role="backend-expert", window="be1"):
    """Build cfg + a fake live pane bound to ``role`` and ``window``.

    Returns (cfg, repo, old_sid, run_calls). ``run_calls`` records every
    tmux invocation (kill-window, new-window, list-panes) so callers
    can assert what was issued.
    """
    repo = tmp_path / "repo"
    repo.mkdir(exist_ok=True)
    cfg = _make_cfg(tmp_path, repo)
    user = "u"
    old_sid = f"S-{user}-{window}-p7"

    # Pre-existing session md for the live pane.
    sessions_dir = cfg.data_dir / "test-project" / "sessions"
    sessions_dir.mkdir(parents=True, exist_ok=True)
    _write_session_metadata(sessions_dir / f"{old_sid}.md", {
        "sid": old_sid,
        "status": "active",
        "window": window,
        "cwd": str(repo),
        "claude_uuid": "old-uuid",
        "task_id": "~",
        "role": role,
    })

    run_calls: list[list[str]] = []
    list_panes_idx = [0]

    def fake_run(args, **kw):
        run_calls.append(list(args))
        # First list-panes after new-window: no panes (snapshot).
        # Second list-panes: the new pane appears (so spawn finds it).
        if "list-panes" in args:
            list_panes_idx[0] += 1
            if list_panes_idx[0] >= 2:
                return subprocess.CompletedProcess(
                    args, 0, f"%99|{window}|2222|{repo}|claude\n", "",
                )
            return subprocess.CompletedProcess(args, 0, "", "")
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: user)
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))
    monkeypatch.setattr(S.time, "sleep", lambda x: None)

    return cfg, repo, old_sid, run_calls


def test_respawn_expert_happy_path(tmp_path, monkeypatch):
    from bot_squad_worker.sessions import respawn_expert
    cfg, repo, old_sid, run_calls = _setup_respawn_fixture(tmp_path, monkeypatch)

    result = respawn_expert(cfg, "test-project", old_sid)
    assert result["ok"] is True
    assert result["old_sid"] == old_sid
    assert result["new_sid"] != old_sid
    assert result["role"] == "backend-expert"
    assert result["window"] == "be1"
    assert result["drained_lines"] == 0  # no unread mail

    # tmux kill-window was issued for the old window.
    kill_calls = [c for c in run_calls if "kill-window" in c]
    assert any("test-project:be1" in c for c in kill_calls), kill_calls

    # tmux new-window was issued (spawn's tmux call).
    new_calls = [c for c in run_calls if "new-window" in c]
    assert new_calls
    # The new window name matches the old.
    assert any(c[c.index("-n") + 1] == "be1" for c in new_calls if "-n" in c)

    # Old session md is gone.
    sess_dir = cfg.data_dir / "test-project" / "sessions"
    assert not (sess_dir / f"{old_sid}.md").exists()


def test_respawn_expert_drains_unread_to_holding(tmp_path, monkeypatch):
    """Unread mail in the old SID's inbox migrates to holding-<role>.log."""
    from bot_squad_worker.sessions import respawn_expert
    cfg, repo, old_sid, _ = _setup_respawn_fixture(tmp_path, monkeypatch)

    # Seed an inbox + seen offset so half the messages are unread.
    chat = cfg.data_dir / "test-project" / "_chat"
    chat.mkdir(parents=True, exist_ok=True)
    inbox = chat / f"inbox-{old_sid}.log"
    inbox.write_text("READ-1\nREAD-2\nUNREAD-3\nUNREAD-4\n")
    seen_offset = len("READ-1\nREAD-2\n")
    (chat / f"seen-{old_sid}").write_text(str(seen_offset))

    result = respawn_expert(cfg, "test-project", old_sid)
    assert result["drained_lines"] == 2

    holding = chat / "holding-backend-expert.log"
    assert holding.exists()
    drained = holding.read_bytes().decode()
    assert "UNREAD-3" in drained
    assert "UNREAD-4" in drained
    assert "READ-1" not in drained  # already-read content stays out


def test_respawn_expert_clears_sleep_mark(tmp_path, monkeypatch):
    """sleep_mark is a byte offset into the old jsonl; respawn invalidates it."""
    from bot_squad_worker.sessions import respawn_expert
    cfg, repo, old_sid, _ = _setup_respawn_fixture(tmp_path, monkeypatch)

    mark = cfg.data_dir / "test-project" / "experts" / "backend-expert" / "sleep_mark"
    mark.parent.mkdir(parents=True, exist_ok=True)
    mark.write_text("12345")

    respawn_expert(cfg, "test-project", old_sid)
    assert not mark.exists()


def test_respawn_expert_rejects_session_without_role(tmp_path, monkeypatch):
    from bot_squad_worker.sessions import respawn_expert
    from bot_squad_worker.actions import ActionError
    repo = tmp_path / "repo"
    repo.mkdir(exist_ok=True)
    cfg = _make_cfg(tmp_path, repo)
    sid = "S-u-leg-p0"
    sess_dir = cfg.data_dir / "test-project" / "sessions"
    sess_dir.mkdir(parents=True, exist_ok=True)
    _write_session_metadata(sess_dir / f"{sid}.md", {
        "sid": sid, "status": "active", "window": "leg",
        "cwd": str(repo), "claude_uuid": "u", "task_id": "T-0001", "role": "~",
    })
    with pytest.raises(ActionError, match="has no role"):
        respawn_expert(cfg, "test-project", sid)


def test_respawn_expert_rejects_unknown_slug(tmp_path, monkeypatch):
    from bot_squad_worker.sessions import respawn_expert
    from bot_squad_worker.actions import ActionError
    repo = tmp_path / "repo"
    repo.mkdir(exist_ok=True)
    cfg = _make_cfg(tmp_path, repo)
    with pytest.raises(ActionError, match="unknown slug"):
        respawn_expert(cfg, "no-such-project", "S-x-y-p0")


def test_respawn_expert_rejects_missing_session_md(tmp_path, monkeypatch):
    from bot_squad_worker.sessions import respawn_expert
    from bot_squad_worker.actions import ActionError
    repo = tmp_path / "repo"
    repo.mkdir(exist_ok=True)
    cfg = _make_cfg(tmp_path, repo)
    with pytest.raises(ActionError, match="no session md"):
        respawn_expert(cfg, "test-project", "S-u-w-p99")


# ---------------------------------------------------------------------------
# Bot-swarm: curated identity templates
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("role,marker", [
    ("planner", "decompose"),
    ("backend-expert", "API contract"),
    ("frontend-expert", "Develop against the contract"),
])
def test_seed_expert_layout_curated_templates_exist(tmp_path, role, marker):
    """All shipped templates seed real content, not stubs."""
    from bot_squad_worker.sessions import _seed_expert_layout
    import types
    cfg = types.SimpleNamespace(data_dir=tmp_path / "data")
    _seed_expert_layout(cfg, "stash", role)
    identity = tmp_path / "data" / "stash" / "experts" / role / "identity.md"
    text = identity.read_text()
    assert marker in text
    assert "TODO:" not in text


def test_seed_expert_layout_falls_back_to_stub_for_novel_role(tmp_path):
    """A role with no template should still seed a stub identity.md."""
    from bot_squad_worker.sessions import _seed_expert_layout
    import types
    cfg = types.SimpleNamespace(data_dir=tmp_path / "data")
    _seed_expert_layout(cfg, "stash", "weird-new-role")
    identity = tmp_path / "data" / "stash" / "experts" / "weird-new-role" / "identity.md"
    assert identity.is_file()
    text = identity.read_text()
    assert "weird-new-role" in text
    assert "TODO:" in text


def test_list_sessions_surfaces_role(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path)
    sessions_dir = tmp_path / "data" / "test-project" / "sessions"
    _write_session_metadata(sessions_dir / "S-u-coord-p7.md", {
        "sid": "S-u-coord-p7",
        "status": "suspended",
        "window": "coord",
        "cwd": "/tmp/repo",
        "claude_uuid": "uuid-coord",
        "task_id": "~",
        "role": "coordinator",
        "started_at": "2026-05-17T10:00:00Z",
    })

    def fake_run(args, **kwargs):
        return subprocess.CompletedProcess(args, 0, "", "")

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "_run", fake_run)
    monkeypatch.setattr(S, "_get_current_user", lambda: "u")
    monkeypatch.setattr(S, "_get_user_home", lambda: str(tmp_path))

    rows = list_sessions(cfg, "test-project")
    row = next(r for r in rows if r["sid"] == "S-u-coord-p7")
    assert row["role"] == "coordinator"
