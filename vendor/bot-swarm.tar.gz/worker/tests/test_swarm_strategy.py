"""Tests for the per-project swarm strategy module."""
from __future__ import annotations

import types
from pathlib import Path

import pytest

from bot_squad_worker import swarm_strategy as ST


def _cfg(tmp_path: Path) -> types.SimpleNamespace:
    return types.SimpleNamespace(
        data_dir=tmp_path / "data",
        projects={"stash": object()},
    )


def test_read_strategy_returns_defaults_when_missing(tmp_path):
    cfg = _cfg(tmp_path)
    out = ST.read_strategy(cfg, "stash")
    assert out == ST.DEFAULT_STRATEGY
    # File NOT created on read — keep the data dir clean.
    assert not (tmp_path / "data" / "stash" / "strategy.toml").exists()


def test_write_strategy_persists_only_non_defaults(tmp_path):
    """strategy.toml should only contain values that differ from
    defaults, so the file stays small and grep-able."""
    cfg = _cfg(tmp_path)
    out = ST.write_strategy(cfg, "stash", {
        "auto_sleep_enabled": True,
        "auto_sleep_threshold_bytes": 50_000,
    })
    assert out["auto_sleep_enabled"] is True
    assert out["auto_sleep_threshold_bytes"] == 50_000
    # Untouched keys came from defaults.
    assert out["auto_sleep_min_interval_sec"] == ST.DEFAULT_STRATEGY["auto_sleep_min_interval_sec"]

    persisted = (tmp_path / "data" / "stash" / "strategy.toml").read_text()
    assert "auto_sleep_enabled = true" in persisted
    assert "auto_sleep_threshold_bytes = 50000" in persisted
    # Default-valued keys NOT persisted.
    assert "auto_sleep_min_interval_sec" not in persisted


def test_write_then_read_roundtrip(tmp_path):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {"auto_sleep_enabled": True})
    assert ST.read_strategy(cfg, "stash")["auto_sleep_enabled"] is True


def test_write_strategy_merges_with_existing(tmp_path):
    """A second write with a different key shouldn't clobber the first."""
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {"auto_sleep_enabled": True})
    ST.write_strategy(cfg, "stash", {"auto_sleep_threshold_bytes": 75_000})
    eff = ST.read_strategy(cfg, "stash")
    assert eff["auto_sleep_enabled"] is True
    assert eff["auto_sleep_threshold_bytes"] == 75_000


def test_write_strategy_can_revert_to_default(tmp_path):
    cfg = _cfg(tmp_path)
    ST.write_strategy(cfg, "stash", {"auto_sleep_enabled": True})
    ST.write_strategy(cfg, "stash", {"auto_sleep_enabled": False})
    # File should no longer carry auto_sleep_enabled (it equals default).
    persisted = (tmp_path / "data" / "stash" / "strategy.toml").read_text()
    assert "auto_sleep_enabled" not in persisted
    assert ST.read_strategy(cfg, "stash")["auto_sleep_enabled"] is False


def test_write_strategy_rejects_unknown_key(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _cfg(tmp_path)
    with pytest.raises(ActionError, match="unknown key"):
        ST.write_strategy(cfg, "stash", {"nonsense_key": 1})


def test_write_strategy_rejects_wrong_type(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _cfg(tmp_path)
    with pytest.raises(ActionError, match="must be bool"):
        ST.write_strategy(cfg, "stash", {"auto_sleep_enabled": "yes"})
    with pytest.raises(ActionError, match="must be int"):
        ST.write_strategy(cfg, "stash", {"auto_sleep_threshold_bytes": 1.5})


def test_write_strategy_rejects_negative_int(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _cfg(tmp_path)
    with pytest.raises(ActionError, match="must be >= 0"):
        ST.write_strategy(cfg, "stash", {"auto_sleep_threshold_bytes": -1})


def test_write_strategy_rejects_bool_for_int_field(tmp_path):
    """Subtle: bool is a subtype of int in Python — we explicitly reject."""
    from bot_squad_worker.actions import ActionError
    cfg = _cfg(tmp_path)
    with pytest.raises(ActionError, match="must be int"):
        ST.write_strategy(cfg, "stash", {"auto_sleep_threshold_bytes": True})


def test_empty_patch_is_noop(tmp_path):
    cfg = _cfg(tmp_path)
    out = ST.write_strategy(cfg, "stash", {})
    assert out == ST.DEFAULT_STRATEGY


def test_read_strategy_rejects_unknown_slug(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _cfg(tmp_path)
    with pytest.raises(ActionError, match="unknown slug"):
        ST.read_strategy(cfg, "no-such-slug")


def test_read_strategy_ignores_unknown_keys_in_file(tmp_path):
    """Forward-compat: a strategy.toml with future-version keys still loads."""
    cfg = _cfg(tmp_path)
    (tmp_path / "data" / "stash").mkdir(parents=True)
    (tmp_path / "data" / "stash" / "strategy.toml").write_text(
        "auto_sleep_enabled = true\n"
        "future_knob_we_dont_know = 42\n"
    )
    out = ST.read_strategy(cfg, "stash")
    assert out["auto_sleep_enabled"] is True
    assert "future_knob_we_dont_know" not in out


def test_read_strategy_raises_on_malformed_toml(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _cfg(tmp_path)
    (tmp_path / "data" / "stash").mkdir(parents=True)
    (tmp_path / "data" / "stash" / "strategy.toml").write_text("this is not = valid toml = nope")
    with pytest.raises(ActionError, match="parse error"):
        ST.read_strategy(cfg, "stash")
