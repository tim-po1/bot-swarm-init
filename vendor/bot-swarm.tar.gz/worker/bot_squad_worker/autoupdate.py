"""Consumer-side autoupdate poller (T-0083).

Each non-mothership bot-squad install runs this tick periodically to poll
the mothership release feed (T-0082) and queue an apply job (T-0084) when
a newer version is published. The apply pipeline itself is out of scope
here — this module only enqueues file-based jobs that T-0084 will drain.

State files (all under ``cfg.data_dir / "_worker"``):

* ``autoupdate.json`` — singleton describing the currently-installed
  version and last-poll bookkeeping. Schema::

      {
        "installed_version": "v2026.05.16.1" | null,
        "last_check_at": "<iso8601>",
        "last_apply_at": "<iso8601>" | null,
        "last_apply_outcome": "success" | "failed:<step>" | "never",
        "current_git_sha": "<sha40>" | null
      }

  ``last_check_at`` is bumped every tick regardless of outcome so the
  operator UI (T-0089) can show liveness.

* ``autoupdate_queue/<uuid>.json`` — apply jobs. Each file is a full
  manifest entry as produced by T-0081 (canonical schema lives in that
  ticket; we treat it as opaque here and forward it verbatim).

Version comparison
------------------

Releases are tagged ``vYYYY.MM.DD.N`` with zero-padded date components
(see T-0081). With ``N`` rarely exceeding a single digit in practice,
lexicographic string comparison agrees with chronological order
(``v2026.05.16.1`` < ``v2026.05.16.2`` < ``v2026.06.01.1``). To stay
correct even when ``N`` rolls into double digits on a busy day, we parse
the trailing counter as an int (``_parse_version``).

Mothership self-exclusion
-------------------------

The poller short-circuits to a no-op on the mothership itself. T-0086
will normally prevent the tick from being scheduled at all, but this is
belt-and-suspenders — the producer of releases must never consume them.
"""
from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import httpx

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Mothership detection — canonical helper from T-0086.
# ---------------------------------------------------------------------------

from bot_squad_worker.install_role import is_mothership


# ---------------------------------------------------------------------------
# Env / constants
# ---------------------------------------------------------------------------

DEFAULT_INTERVAL_SECONDS = 900  # 15 minutes (overridable via env)
DEFAULT_HTTP_TIMEOUT_SECONDS = 10.0
LATEST_PATH = "/api/releases/latest"


def interval_seconds() -> int:
    """Tick cadence, in seconds. Reads ``BOT_SQUAD_AUTOUPDATE_INTERVAL_SECONDS``."""
    raw = os.environ.get("BOT_SQUAD_AUTOUPDATE_INTERVAL_SECONDS")
    if not raw:
        return DEFAULT_INTERVAL_SECONDS
    try:
        v = int(raw)
        return v if v > 0 else DEFAULT_INTERVAL_SECONDS
    except ValueError:
        log.warning(
            "autoupdate: invalid BOT_SQUAD_AUTOUPDATE_INTERVAL_SECONDS=%r; using default",
            raw,
        )
        return DEFAULT_INTERVAL_SECONDS


def mothership_url() -> Optional[str]:
    """Resolve the mothership base URL from env.

    Primary key: ``BOT_SQUAD_MOTHERSHIP_URL`` (canonical for this initiative).
    Fallback: ``BOTSQUAD_MOTHERSHIP_URL`` (the install-script convention from
    ``scripts/install/install.sh``; kept for parity with existing consumers).
    """
    url = (
        os.environ.get("BOT_SQUAD_MOTHERSHIP_URL")
        or os.environ.get("BOTSQUAD_MOTHERSHIP_URL")
    )
    if not url:
        return None
    return url.rstrip("/")


# ---------------------------------------------------------------------------
# State paths / I/O
# ---------------------------------------------------------------------------

def state_path(cfg: Any) -> Path:
    return cfg.data_dir / "_worker" / "autoupdate.json"


def queue_dir(cfg: Any) -> Path:
    return cfg.data_dir / "_worker" / "autoupdate_queue"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_state(cfg: Any) -> dict:
    """Return the autoupdate.json contents (default skeleton if missing)."""
    p = state_path(cfg)
    if not p.exists():
        return {
            "installed_version": None,
            "last_check_at": None,
            "last_apply_at": None,
            "last_apply_outcome": "never",
            "current_git_sha": None,
        }
    try:
        return json.loads(p.read_text())
    except (OSError, json.JSONDecodeError) as e:
        log.warning("autoupdate: could not parse %s: %s; treating as missing", p, e)
        return {
            "installed_version": None,
            "last_check_at": None,
            "last_apply_at": None,
            "last_apply_outcome": "never",
            "current_git_sha": None,
        }


def save_state(cfg: Any, state: dict) -> None:
    p = state_path(cfg)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(state, indent=2, sort_keys=True))


# ---------------------------------------------------------------------------
# Version compare
# ---------------------------------------------------------------------------

def _parse_version(v: str) -> tuple[int, int, int, int]:
    """Parse ``vYYYY.MM.DD.N`` into a sortable tuple.

    Tolerant: a malformed version sorts as the smallest possible tuple so
    that a malformed *installed* version always loses to a sane manifest
    entry (we'd rather try to update than get stuck).
    """
    s = v[1:] if v.startswith("v") else v
    parts = s.split(".")
    try:
        y = int(parts[0])
        m = int(parts[1])
        d = int(parts[2])
        n = int(parts[3]) if len(parts) > 3 else 0
    except (IndexError, ValueError):
        return (-1, -1, -1, -1)
    return (y, m, d, n)


def is_newer(candidate: str, installed: str) -> bool:
    """True iff ``candidate`` > ``installed`` under the release scheme."""
    return _parse_version(candidate) > _parse_version(installed)


# ---------------------------------------------------------------------------
# HTTP fetch
# ---------------------------------------------------------------------------

def _fetch_latest(base_url: str, *, timeout: float = DEFAULT_HTTP_TIMEOUT_SECONDS) -> Optional[dict]:
    """GET ``<base>/api/releases/latest``; one retry on transient network error.

    Returns the manifest entry dict on success, ``None`` on permanent failure
    (network, non-2xx, or non-JSON body). Caller is responsible for the
    success/failure bookkeeping in autoupdate.json.

    Factored out so T-0088 can piggy-back a telemetry POST on the same tick
    without re-doing the polling/retry logic.
    """
    url = f"{base_url.rstrip('/')}{LATEST_PATH}"
    last_err: Optional[Exception] = None
    for attempt in (1, 2):
        try:
            resp = httpx.get(url, timeout=timeout)
            resp.raise_for_status()
            entry = resp.json()
            if not isinstance(entry, dict):
                log.warning("autoupdate: unexpected body shape from %s: %r", url, type(entry))
                return None
            return entry
        except (httpx.TransportError, httpx.TimeoutException) as e:
            last_err = e
            log.info(
                "autoupdate: transient fetch error (attempt %d) for %s: %s",
                attempt, url, e,
            )
            continue
        except httpx.HTTPStatusError as e:
            log.warning("autoupdate: HTTP %d from %s", e.response.status_code, url)
            return None
        except (ValueError, json.JSONDecodeError) as e:
            log.warning("autoupdate: non-JSON body from %s: %s", url, e)
            return None
    log.warning("autoupdate: gave up after retry for %s: %s", url, last_err)
    return None


# ---------------------------------------------------------------------------
# Apply-job queue
# ---------------------------------------------------------------------------

def _enqueue_apply(cfg: Any, entry: dict) -> Path:
    """Write the manifest entry to a fresh queue file. Returns the path."""
    qdir = queue_dir(cfg)
    qdir.mkdir(parents=True, exist_ok=True)
    p = qdir / f"{uuid.uuid4().hex}.json"
    p.write_text(json.dumps(entry, indent=2, sort_keys=True))
    return p


# ---------------------------------------------------------------------------
# Per-tick handler — factored so T-0088 can plug a telemetry POST in here.
# ---------------------------------------------------------------------------

def _handle_latest(cfg: Any, entry: dict) -> str:
    """Compare ``entry`` to the recorded installed version and act.

    Returns one of:

    * ``"first_run_stamped"`` — no prior state; stamped manifest as installed.
    * ``"enqueued"`` — newer version detected; apply job written.
    * ``"up_to_date"`` — manifest version matches installed.
    * ``"older"``     — manifest version is older than installed (no-op).
    * ``"bad_entry"`` — manifest entry missing required fields (no-op).
    """
    version = entry.get("version")
    if not isinstance(version, str) or not version:
        log.warning("autoupdate: manifest entry missing 'version': %r", entry)
        return "bad_entry"

    state = load_state(cfg)
    installed = state.get("installed_version")

    if not installed:
        # First run: we don't know what's actually installed, but the spec
        # says assume aligned with the current latest — do NOT apply.
        state["installed_version"] = version
        state["current_git_sha"] = entry.get("git_sha") or state.get("current_git_sha")
        save_state(cfg, state)
        log.info("autoupdate: first-run stamp -> installed_version=%s", version)
        return "first_run_stamped"

    if is_newer(version, installed):
        path = _enqueue_apply(cfg, entry)
        log.info(
            "autoupdate: newer version available (%s > %s); enqueued %s",
            version, installed, path.name,
        )
        return "enqueued"

    if version == installed:
        return "up_to_date"

    log.debug("autoupdate: manifest version %s older than installed %s — ignoring",
              version, installed)
    return "older"


# ---------------------------------------------------------------------------
# Public tick
# ---------------------------------------------------------------------------

def tick(cfg: Any) -> None:
    """One poll cycle. Safe to call from APScheduler.

    Bumps ``last_check_at`` on every invocation (even on transient failures)
    so the operator UI can distinguish "poller alive but mothership down"
    from "poller dead".
    """
    # Belt-and-suspenders mothership exclusion (T-0086 should also prevent
    # scheduling this tick at all).
    if is_mothership():
        log.debug("autoupdate: mothership self-exclusion — tick is a no-op")
        return

    base_url = mothership_url()
    if not base_url:
        log.debug("autoupdate: BOT_SQUAD_MOTHERSHIP_URL not set — tick is a no-op")
        return

    # Touch last_check_at up front so a crash mid-fetch still records the
    # attempt. We rewrite state again on success.
    state = load_state(cfg)
    state["last_check_at"] = _now_iso()
    save_state(cfg, state)

    entry = _fetch_latest(base_url)
    if entry is None:
        # last_check_at is already stamped; nothing else to do.
        return

    try:
        _handle_latest(cfg, entry)
    except Exception:
        log.exception("autoupdate: _handle_latest raised on entry=%r", entry)
