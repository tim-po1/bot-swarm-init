"""Cross-session message bus.

Ports the cctv-backend ``ops/intersession.sh`` pattern into a worker action
surface. Three primitives:

- ``send`` appends a message line to the recipient's inbox log; recipients
  can be a literal SID or a role keyword (``teamlead`` / ``dev`` / ``all``).
- ``inbox_read`` drains lines since the high-water mark.
- ``inbox_wait`` long-polls until the inbox file grows past the mark or a
  timeout elapses. Designed to be invoked from Claude Code with
  ``run_in_background: true`` so the harness's task-notification fires when
  this returns — that's the no-polling push primitive.

File layout under ``data/<slug>/_chat/``:
    inbox-<sid>.log    append-only, one message per line
    seen-<sid>         single int (byte offset), read high-water mark
    heartbeat-<sid>    mtime touched while wait/read is running
"""
from __future__ import annotations

import os
import stat
import time
from pathlib import Path
from typing import Any

_MAX_TEXT_LEN = 4000
_MAX_WAIT_TIMEOUT = 1800
_HEARTBEAT_INTERVAL = 10.0


def _chat_dir(cfg: Any, slug: str) -> Path:
    """Return data/<slug>/_chat, creating it 770 if missing."""
    d = Path(cfg.data_dir) / slug / "_chat"
    if not d.exists():
        d.mkdir(parents=True, exist_ok=True)
        try:
            d.chmod(stat.S_IRWXU | stat.S_IRWXG)  # 770
        except OSError:
            pass
    return d


def _sanitize(text: str) -> str:
    text = text.replace("\r\n", " ").replace("\r", " ").replace("\n", " ").replace("\t", " ")
    if len(text) > _MAX_TEXT_LEN:
        text = text[:_MAX_TEXT_LEN]
    return text


def _list_session_sids(cfg: Any, slug: str) -> list[tuple[str, dict]]:
    """Parse session md frontmatter for every session in data/<slug>/sessions/.

    Returns (sid, meta) tuples. Meta values are raw strings (no type coercion).
    """
    sess_dir = Path(cfg.data_dir) / slug / "sessions"
    if not sess_dir.exists():
        return []
    out: list[tuple[str, dict]] = []
    for md in sorted(sess_dir.glob("*.md")):
        text = md.read_text()
        if not text.startswith("---"):
            continue
        parts = text.split("---", 2)
        if len(parts) < 3:
            continue
        meta: dict[str, str] = {}
        for line in parts[1].strip().splitlines():
            if ":" not in line:
                continue
            k, _, v = line.partition(":")
            meta[k.strip()] = v.strip()
        sid = meta.get("sid", md.stem)
        out.append((sid, meta))
    return out


def _resolve_recipients(cfg: Any, slug: str, to: str) -> list[str]:
    """Map a recipient spec to a list of SIDs.

    Recipient kinds (resolved in this order):
      - ``teamlead`` / ``dev`` / ``all``: bot-squad legacy role keywords.
      - SID literal: anything starting with ``S-`` (the SID format).
      - Role keyword: anything else is treated as a swarm role name
        (e.g. ``coordinator``, ``planner``, ``backend-expert``) and matches
        every session whose ``role:`` frontmatter equals it. An empty list
        means no live session embodies that role — the caller (``send``)
        falls back to the holding inbox.
    """
    if to in {"teamlead", "dev", "all"}:
        sids: list[str] = []
        for sid, meta in _list_session_sids(cfg, slug):
            tid = meta.get("task_id", "") or ""
            is_dev = bool(tid) and tid != "~"
            if to == "all":
                sids.append(sid)
            elif to == "teamlead" and not is_dev:
                sids.append(sid)
            elif to == "dev" and is_dev:
                sids.append(sid)
        return sids
    if to.startswith("S-"):
        return [to]
    # Treat as swarm role keyword: broadcast to every session with role: <to>.
    sids = []
    for sid, meta in _list_session_sids(cfg, slug):
        if (meta.get("role") or "") == to:
            sids.append(sid)
    return sids


def _is_role_keyword(to: str) -> bool:
    """True iff ``to`` is shaped like a swarm role keyword (not a SID,
    not a legacy keyword).
    """
    if to in {"teamlead", "dev", "all"}:
        return False
    if to.startswith("S-"):
        return False
    return bool(to)


def _holding_path(cfg: Any, slug: str, role: str) -> Path:
    return _chat_dir(cfg, slug) / f"holding-{role}.log"


def _role_for_sid(cfg: Any, slug: str, sid: str) -> str | None:
    """Read this session's md and return its ``role:`` field, or None."""
    md = Path(cfg.data_dir) / slug / "sessions" / f"{sid}.md"
    if not md.exists():
        return None
    text = md.read_text()
    if not text.startswith("---"):
        return None
    parts = text.split("---", 2)
    if len(parts) < 3:
        return None
    for line in parts[1].strip().splitlines():
        if ":" not in line:
            continue
        k, _, v = line.partition(":")
        if k.strip() == "role":
            v = v.strip()
            return v if v and v != "~" else None
    return None


def drain_unread_to_holding(cfg: Any, slug: str, sid: str, role: str) -> int:
    """Move any UNREAD mail (bytes past ``seen-<sid>``) from inbox-<sid>
    into holding-<role>.log. Used when a pane is respawned: the new pane
    has a fresh SID, so unread mail in the old SID's inbox would be
    orphaned. Draining into the role's holding inbox routes it to
    whichever same-role pane reads next.

    Returns the number of message lines drained.
    """
    inbox = _inbox_path(cfg, slug, sid)
    seen = _seen_path(cfg, slug, sid)
    if not inbox.exists():
        return 0
    try:
        offset = int(seen.read_text().strip()) if seen.exists() else 0
    except (FileNotFoundError, ValueError):
        offset = 0
    try:
        size = inbox.stat().st_size
    except FileNotFoundError:
        return 0
    if size <= offset:
        return 0
    with inbox.open("rb") as f:
        f.seek(offset)
        unread = f.read(size - offset)
    if not unread:
        return 0
    holding = _holding_path(cfg, slug, role)
    with holding.open("ab") as f:
        f.write(unread)
    seen.write_text(str(size))
    return unread.count(b"\n")


def _drain_holding(cfg: Any, slug: str, role: str, sid: str) -> None:
    """Append any pending holding-<role>.log content into this session's
    inbox, then truncate the holding log. Best-effort, no locking — if two
    sessions of the same role drain concurrently one gets the lines and
    the other gets an empty drain. v1 broadcast semantics tolerate that.
    """
    holding = _holding_path(cfg, slug, role)
    if not holding.exists():
        return
    try:
        buf = holding.read_bytes()
    except OSError:
        return
    if not buf:
        return
    inbox = _inbox_path(cfg, slug, sid)
    with inbox.open("ab") as f:
        f.write(buf)
    try:
        holding.write_bytes(b"")
    except OSError:
        pass


def _inbox_path(cfg: Any, slug: str, sid: str) -> Path:
    return _chat_dir(cfg, slug) / f"inbox-{sid}.log"


def _seen_path(cfg: Any, slug: str, sid: str) -> Path:
    return _chat_dir(cfg, slug) / f"seen-{sid}"


def _heartbeat_path(cfg: Any, slug: str, sid: str) -> Path:
    return _chat_dir(cfg, slug) / f"heartbeat-{sid}"


def _touch(p: Path) -> None:
    try:
        p.touch(exist_ok=True)
    except OSError:
        pass


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def send(cfg: Any, slug: str, from_sid: str, to: str, text: str) -> dict:
    """Append a message line to recipient inboxes.

    For a swarm role keyword with zero live sessions, writes to the role's
    holding inbox at ``_chat/holding-<role>.log``; the first session of
    that role to spawn will drain it on its next ``inbox_read``.

    Returns ``{"ok": True, "delivered_to": [sid, ...], "held_for": <role>?}``.
    """
    sanitized = _sanitize(text)
    recipients = _resolve_recipients(cfg, slug, to)
    line = f"{_now_iso()}\t[from {from_sid}]\t{sanitized}\n"
    delivered: list[str] = []
    for sid in recipients:
        inbox = _inbox_path(cfg, slug, sid)
        with inbox.open("ab") as f:
            f.write(line.encode("utf-8"))
        delivered.append(sid)
    if not delivered and _is_role_keyword(to):
        holding = _holding_path(cfg, slug, to)
        with holding.open("ab") as f:
            f.write(line.encode("utf-8"))
        return {"ok": True, "delivered_to": [], "held_for": to}
    return {"ok": True, "delivered_to": delivered}


def inbox_read(cfg: Any, slug: str, sid: str) -> dict:
    """Drain inbox lines since the seen-<sid> byte offset.

    Before reading, drains any pending holding-<role>.log into this
    session's inbox if the session has a role. That covers messages
    addressed to the role while no session of that role was live.
    """
    _touch(_heartbeat_path(cfg, slug, sid))
    role = _role_for_sid(cfg, slug, sid)
    if role:
        _drain_holding(cfg, slug, role, sid)
    inbox = _inbox_path(cfg, slug, sid)
    seen = _seen_path(cfg, slug, sid)
    if not inbox.exists():
        # Touch a zero-byte inbox so subsequent waits have something to watch.
        inbox.touch()
    try:
        offset = int(seen.read_text().strip())
    except (FileNotFoundError, ValueError):
        offset = 0
    size = inbox.stat().st_size
    messages: list[str] = []
    if size > offset:
        with inbox.open("rb") as f:
            f.seek(offset)
            buf = f.read(size - offset)
        text = buf.decode("utf-8", errors="replace")
        # Split on real newlines, drop the trailing empty from the final \n.
        messages = [m for m in text.split("\n") if m]
        seen.write_text(str(size))
    return {"ok": True, "messages": messages, "count": len(messages)}


def inbox_wait(cfg: Any, slug: str, sid: str, timeout: float) -> dict:
    """Long-poll for inbox growth.

    Returns ``{"ok": True, "ready": bool, "elapsed_sec": float}``. ``ready``
    True means "you have new mail, call ``inbox_read``"; False means the
    timeout expired without new mail.
    """
    timeout = max(0.0, min(float(timeout), float(_MAX_WAIT_TIMEOUT)))
    inbox = _inbox_path(cfg, slug, sid)
    seen = _seen_path(cfg, slug, sid)
    hb = _heartbeat_path(cfg, slug, sid)
    if not inbox.exists():
        inbox.touch()
    try:
        offset = int(seen.read_text().strip())
    except (FileNotFoundError, ValueError):
        offset = 0

    start = time.monotonic()
    deadline = start + timeout
    last_hb = 0.0
    # Plain stat() poll (1s) — keeps the implementation portable. Linux
    # inotify would only buy us sub-second wake latency, and the message
    # bus's latency budget is "human-perceptible turn", not sub-second.
    poll_interval = 1.0
    while True:
        now = time.monotonic()
        if now - last_hb >= _HEARTBEAT_INTERVAL:
            _touch(hb)
            last_hb = now
        try:
            size = inbox.stat().st_size
        except FileNotFoundError:
            size = 0
        if size > offset:
            return {"ok": True, "ready": True, "elapsed_sec": now - start}
        if now >= deadline:
            return {"ok": True, "ready": False, "elapsed_sec": now - start}
        sleep_for = min(poll_interval, deadline - now)
        if sleep_for > 0:
            time.sleep(sleep_for)
