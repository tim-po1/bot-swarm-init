#!/usr/bin/env bash
# bot-swarm install — sets up venvs, web deps, config templates, and
# CLI symlinks. Idempotent: re-runnable.
#
# Run from inside the bot-swarm repo:
#   ./install.sh
set -euo pipefail

ROOT="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
cd "$ROOT"

red()    { printf "\033[31m%s\033[0m\n" "$*" >&2; }
yellow() { printf "\033[33m%s\033[0m\n" "$*"; }
green()  { printf "\033[32m%s\033[0m\n" "$*"; }
say()    { printf "%s\n" "$*"; }

# ---------------------------------------------------------------------------
# Dependency checks
# ---------------------------------------------------------------------------

require() {
    local cmd="$1" pretty="${2:-$1}"
    if ! command -v "$cmd" >/dev/null 2>&1; then
        red "missing: $pretty"
        red "install it and re-run ./install.sh"
        return 1
    fi
}

say "[1/6] checking dependencies …"
missing=0
require python3 "Python 3.12+" || missing=1
require node "Node 20+ (with npm)" || missing=1
require npm || missing=1
require tmux || missing=1
require claude "Claude Code CLI (https://docs.anthropic.com/claude-code)" || missing=1
require git || missing=1
require curl || missing=1
[ $missing -eq 0 ] || exit 1

# Python version
PY_MAJOR=$(python3 -c 'import sys; print(sys.version_info[0])')
PY_MINOR=$(python3 -c 'import sys; print(sys.version_info[1])')
if [ "$PY_MAJOR" -lt 3 ] || { [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 12 ]; }; then
    red "Python 3.12+ required (found $PY_MAJOR.$PY_MINOR)"
    exit 1
fi
green "✓ deps ok (python $PY_MAJOR.$PY_MINOR, node $(node --version), tmux $(tmux -V | awk '{print $2}'))"

# ---------------------------------------------------------------------------
# Worker venv
# ---------------------------------------------------------------------------

say
say "[2/6] worker: creating venv + installing …"
if [ ! -d worker/.venv ]; then
    python3 -m venv worker/.venv
fi
worker/.venv/bin/pip install --upgrade pip --quiet
worker/.venv/bin/pip install -e 'worker/.[dev]' --quiet
green "✓ worker venv ready"

# ---------------------------------------------------------------------------
# API venv
# ---------------------------------------------------------------------------

say
say "[3/6] api: creating venv + installing …"
if [ ! -d api/.venv ]; then
    python3 -m venv api/.venv
fi
api/.venv/bin/pip install --upgrade pip --quiet
api/.venv/bin/pip install -e 'api/.[dev]' --quiet
green "✓ api venv ready"

# ---------------------------------------------------------------------------
# Web build deps
# ---------------------------------------------------------------------------

say
say "[4/6] web: npm install …"
( cd web && npm install --no-audit --no-fund --silent )
green "✓ web deps ready"

# ---------------------------------------------------------------------------
# Config templates (create if missing — never clobber)
# ---------------------------------------------------------------------------

say
say "[5/6] config templates …"

mkdir -p config data/_sock data/_worker

# projects.toml — empty registry. swarm CLI / dashboard add entries.
if [ ! -f config/projects.toml ]; then
    cat > config/projects.toml <<'TOML'
# bot-swarm projects — managed by the dashboard UI and the swarm CLI.
# New projects get appended here automatically. Edit by hand if needed.
TOML
    green "✓ wrote config/projects.toml"
else
    yellow "  config/projects.toml exists — leaving alone"
fi

# secrets.toml — empty Telegram. Fill in when wiring notifications.
if [ ! -f config/secrets.toml ]; then
    cat > config/secrets.toml <<'TOML'
[telegram]
bot_token = ""
TOML
    green "✓ wrote config/secrets.toml"
else
    yellow "  config/secrets.toml exists — leaving alone"
fi

# auth.toml — prompt for username + password unless one already exists.
if [ ! -f config/auth.toml ]; then
    say
    say "  setting up dashboard login (one admin user):"
    # Read from /dev/tty so prompts work even when stdin is piped (e.g.
    # `ssh remote cat install.sh | bash`). Falls back to stdin if no tty.
    if [ -r /dev/tty ]; then
        read -rp "    username: " USERNAME </dev/tty
        read -rsp "    password: " PASSWORD </dev/tty; echo
    else
        read -rp "    username: " USERNAME
        read -rsp "    password: " PASSWORD; echo
    fi
    LINUX_USER="$(id -un)"
    HASH=$(api/.venv/bin/python3 - <<PY
import bcrypt
print(bcrypt.hashpw("${PASSWORD}".encode(), bcrypt.gensalt(rounds=12)).decode())
PY
)
    cat > config/auth.toml <<TOML
# bot-swarm auth. Add more users / change passwords by re-running this
# install or editing by hand.

[users]
${USERNAME} = "${HASH}"

[user_meta.${USERNAME}]
linux_user = "${LINUX_USER}"
is_admin = true

[session]
ttl = "7d"
TOML
    green "✓ wrote config/auth.toml (user: $USERNAME)"
else
    yellow "  config/auth.toml exists — leaving alone (delete + rerun to reset)"
fi

# ---------------------------------------------------------------------------
# CLI symlinks
# ---------------------------------------------------------------------------

say
say "[6/6] CLI symlinks …"

LOCAL_BIN="${LOCAL_BIN:-$HOME/.local/bin}"
mkdir -p "$LOCAL_BIN"

for tool in swarm bot-swarm; do
    src="$ROOT/scripts/cli/$tool"
    dst="$LOCAL_BIN/$tool"
    if [ -f "$src" ]; then
        chmod +x "$src"
        ln -sf "$src" "$dst"
        green "✓ $dst -> $src"
    fi
done

case ":$PATH:" in
    *":$LOCAL_BIN:"*) ;;
    *)
        yellow "  $LOCAL_BIN is not on your PATH."
        yellow "  add this to your shell rc (~/.bashrc or ~/.zshrc):"
        yellow "    export PATH=\"$LOCAL_BIN:\$PATH\""
        ;;
esac

say
green "Installed."
say
say "Start the stack:"
say "  bot-swarm up"
say
say "Then in any project directory:"
say "  cd /path/to/your/repo && swarm"
